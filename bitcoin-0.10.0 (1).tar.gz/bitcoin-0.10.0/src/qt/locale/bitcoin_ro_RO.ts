<TS language="ro_RO" version="2.0">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Dublu-click pentru a edita adresa sau eticheta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Creează o adresă nouă</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Nou</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copiază adresa selectată în clipboard</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiere</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Inchidere</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Copiază adresa</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Sterge adresele curent selectate din lista</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporta datele din tab-ul curent într-un fișier</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportă</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>Ște&amp;rge</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Alegeti adresa unde vreti sa trimiteti monezile</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Alegeti adresa unde vreti sa primiti monezile</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>&amp;Alege</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Adresa Destinatarului</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Adresa pe care primiti</translation>
    </message>
    <message>
        <source>These are your Bitcoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Acestea sunt adresele dumneavoastra Bitcoin care pot fi folosite la trimiterea platilor. Verificati totdeauna cantitatea si adresa de primire inainte de a trimite monezi.</translation>
    </message>
    <message>
        <source>These are your Bitcoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Acestea sunt adresele dumneavoastra Bitcoin folosite pentru a primi plati. Este recomandat sa folositi cate o adresa noua de primire pentru fiecare tranzactie in parte.</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Copiază &amp;eticheta</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editează</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Exportati Agenda</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Valori separate prin virgulă (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Exportare esuata</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Etichetă</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresă</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(fără etichetă)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Dialogul pentru fraza de acces</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Introdu fraza de acces</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Frază de acces nouă</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Repetă noua frază de acces</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Criptează portofelul</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Această acțiune necesită fraza ta de acces pentru deblocarea portofelului.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Deblochează portofelul</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Această acțiune necesită fraza ta de acces pentru decriptarea portofelului.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Decriptează portofelul.</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Schimbă fraza de acces</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Introdu vechea și noua parolă pentru portofel.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Confirmă criptarea portofelului</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BITCOINS&lt;/b&gt;!</source>
        <translation>Atenție: Dacă pierdeţi parola portofelului electronic dupa criptare, &lt;b&gt;VEŢI PIERDE ÎNTREAGA SUMĂ DE BITCOIN ACUMULATĂ&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Sunteţi sigur că doriţi să criptaţi portofelul electronic?</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>IMPORTANT: Orice copie de siguranta facuta in prealabil portofelului dumneavoastra ar trebui inlocuita cu cea generata cel mai recent fisier criptat al portofelului. Pentru siguranta, copiile de siguranta vechi ale portofelului ne-criptat vor deveni inutile de indata ce veti incepe folosirea noului fisier criptat al portofelului.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Atentie! Caps Lock este pornit</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Portofel criptat</translation>
    </message>
    <message>
        <source>Bitcoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your bitcoins from being stolen by malware infecting your computer.</source>
        <translation>Bitcoin se va închide acum pentru a termina procesul de criptare. Ține minte că criptarea portofelului nu te poate proteja în totalitate de furtul monedelor de către programe dăunătoare care îți infectează calculatorul.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Criptarea portofelului a eșuat</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Criptarea portofelului a eșuat din cauza unei erori interne. Portofelul tău nu a fost criptat.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Frazele de acces introduse nu se potrivesc.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Deblocarea portofelului a eșuat</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Fraza de acces introdusă pentru decriptarea portofelului a fost incorectă.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Decriptarea portofelului a eșuat</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Parola portofelului electronic a fost schimbată.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Semnează &amp;mesaj...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Se sincronizează cu rețeaua...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Imagine de ansamblu</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nod</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Arată o stare generală de ansamblu a portofelului</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Tranzacții</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Răsfoiește istoricul tranzacțiilor</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Ieșire</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Închide aplicația</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Despre &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Arată informații despre Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Setări...</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>Criptează portofelul electronic...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Fă o copie de siguranță a  portofelului...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>S&amp;chimbă parola...</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Trimitere adrese...</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Primire adrese...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Vizitaţi &amp;URI...</translation>
    </message>
    <message>
        <source>Importing blocks from disk...</source>
        <translation>Importare blocks de pe disk...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Se reindexează blocurile pe disc...</translation>
    </message>
    <message>
        <source>Send coins to a Bitcoin address</source>
        <translation>Trimite monede către o adresă Bitcoin</translation>
    </message>
    <message>
        <source>Modify configuration options for Bitcoin</source>
        <translation>Modifică opțiunile de configurare pentru Bitcoin</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Creează o copie de rezervă a portofelului într-o locație diferită</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Schimbă fraza de acces folosită pentru criptarea portofelului</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>Fereastră &amp;debug</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Deschide consola de debug și diagnosticare</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Verifică mesajul...</translation>
    </message>
    <message>
        <source>Bitcoin</source>
        <translation>Bitcoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Portofelul</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Trimite</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Primește</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>Arata/Ascunde</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Arată sau ascunde fereastra principală</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Criptează cheile private ale portofelului tău</translation>
    </message>
    <message>
        <source>Sign messages with your Bitcoin addresses to prove you own them</source>
        <translation>Semnează mesaje cu adresa ta Bitcoin pentru a dovedi că îți aparțin</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Bitcoin addresses</source>
        <translation>Verifică mesaje pentru a te asigura că au fost semnate cu adresa Bitcoin specificată</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fișier</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Setări</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>A&amp;jutor</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Bara de file</translation>
    </message>
    <message>
        <source>Bitcoin Core</source>
        <translation>Bitcoin Core</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and bitcoin: URIs)</source>
        <translation>Cereti plati (genereaza coduri QR si bitcoin-uri: URls)</translation>
    </message>
    <message>
        <source>&amp;About Bitcoin Core</source>
        <translation>&amp;Despre Nucleul Bitcoin</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Aratati lista de adrese trimise si etichete folosite.</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Aratati lista de adrese pentru primire si etichete </translation>
    </message>
    <message>
        <source>Open a bitcoin: URI or payment request</source>
        <translation>Deschideti un bitcoin: o adresa URI sau o cerere de plata</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>Command-line setări</translation>
    </message>
    <message>
        <source>Show the Bitcoin Core help message to get a list with possible Bitcoin command-line options</source>
        <translation>Arată mesajul de ajutor Bitcoin Core pentru a obține o listă cu opțiunile posibile de linii de comandă Bitcoin</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Bitcoin network</source>
        <translation><numerusform>%n conexiune activă către rețeaua Bitcoin</numerusform><numerusform>%n conexiuni active către rețeaua Bitcoin</numerusform><numerusform>%n de conexiuni active către rețeaua Bitcoin</numerusform></translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation>Nici o sursă de bloc disponibil ...</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n oră</numerusform><numerusform>%n ore</numerusform><numerusform>%n ore</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n zi</numerusform><numerusform>%n zile</numerusform><numerusform>%n zile</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n săptămână</numerusform><numerusform>%n săptămâni</numerusform><numerusform>%n de săptămâni</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 si %2</translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 în urmă</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Ultimul bloc recepționat a fost generat acum %1.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Tranzacții după aceasta nu va fi încă disponibile.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Eroare</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Avertizare</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informație</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Actualizat</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Se actualizează...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Tranzacție expediată</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Tranzacție recepționată</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Data: %1
Suma: %2
Tipul: %3
Adresa: %4
</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Portofelul este &lt;b&gt;criptat&lt;/b&gt; iar în momentul de față este &lt;b&gt;deblocat&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Portofelul este &lt;b&gt;criptat&lt;/b&gt; iar în momentul de față este &lt;b&gt;blocat&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Network Alert</source>
        <translation>Alertă rețea</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>Cantitate:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Octeţi:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Sumă:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioritate:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Taxa:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>După taxe:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Schimb:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>(de)selectaţi tot</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Modul arborescent</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Modul lista</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Sumă</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Confirmări</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmat</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritate</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Copiază adresa</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copiază eticheta</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copiază suma</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Copiază ID tranzacție</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>Blocaţi necheltuite</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>Deblocaţi necheltuite</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Copiaţi quantitea</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Copiaţi taxele</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Copiaţi după taxe</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Copiaţi octeţi</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Copiaţi prioritatea</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Copiaţi schimb</translation>
    </message>
    <message>
        <source>highest</source>
        <translation>cel mai mare</translation>
    </message>
    <message>
        <source>higher</source>
        <translation>mai mare</translation>
    </message>
    <message>
        <source>high</source>
        <translation>mare</translation>
    </message>
    <message>
        <source>medium-high</source>
        <translation>marime medie</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>mediu</translation>
    </message>
    <message>
        <source>low-medium</source>
        <translation>mediu-scazut</translation>
    </message>
    <message>
        <source>low</source>
        <translation>scazut</translation>
    </message>
    <message>
        <source>lower</source>
        <translation>mai scazut</translation>
    </message>
    <message>
        <source>lowest</source>
        <translation>cel mai scazut</translation>
    </message>
    <message>
        <source>none</source>
        <translation>nimic</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>da</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nu</translation>
    </message>
    <message>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation>Această etichetă devine roşie, în cazul în care dimensiunea tranzacţiei este mai mare de 1000 de octeţi. </translation>
    </message>
    <message>
        <source>Can vary +/- 1 byte per input.</source>
        <translation>Poate varia +/- 1 octet pentru fiecare intrare. </translation>
    </message>
    <message>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation>Tranzacţiile cu prioritate mai mare sunt mai susceptibile de fi incluse într-un bloc. </translation>
    </message>
    <message>
        <source>This label turns red, if the priority is smaller than "medium".</source>
        <translation>Aceasta eticheta se face rosie daca prioritatea e mai mica decat media</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(fără etichetă)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>restul de la %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(schimb)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Editează adresa</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Etichetă</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Etichetele asociate cu aceasta intrare din lista.</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>Adresa asociata cu aceasta adresa din lista. Aceasta poate fi modificata doar pentru Destinatari.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adresă</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Noua adresă de primire</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Noua adresă de trimitere</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Editează adresa de primire</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Editează adresa de trimitere</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>Adresa introdusă "%1" se află deja în lista de adrese.</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Bitcoin address.</source>
        <translation>Adresa introdusă "%1" nu este o adresă bitcoin validă.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Portofelul nu a putut fi deblocat.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Generarea noii chei a eșuat.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Va fi creat un nou dosar de date.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>nume</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Dosarul deja există. Adaugă %1 dacă intenționezi să creezi un nou dosar aici.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Calea deja există și nu este un dosar.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Nu se poate crea un dosar de date aici.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Bitcoin Core</source>
        <translation>Bitcoin Core</translation>
    </message>
    <message>
        <source>version</source>
        <translation>versiunea</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-bit)</translation>
    </message>
    <message>
        <source>About Bitcoin Core</source>
        <translation>Despre Nucleul Bitcoin</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Command-line setări</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Uz:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>command-line setări</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>UI setări</translation>
    </message>
    <message>
        <source>Set language, for example "de_DE" (default: system locale)</source>
        <translation>Seteaza limba, de exemplu: "de_DE" (initialt: system locale)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Incepe miniaturizare</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Afișează pe ecran splash la pornire (implicit: 1)</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation>Alege dosarul de date la pornire (implicit: 0)</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Bun venit</translation>
    </message>
    <message>
        <source>Welcome to Bitcoin Core.</source>
        <translation>Bine Aţi Venit la Nucleul Bitcoin.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where Bitcoin Core will store its data.</source>
        <translation>Dacă aceasta este prima dată când programul este lansat, puteţi alege unde Nucleul Bitcoin va stoca datele. </translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Folosește dosarul de date implicit</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Folosește un dosar de date personalizat:</translation>
    </message>
    <message>
        <source>Bitcoin Core</source>
        <translation>Bitcoin Core</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Eroare</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Deschideti adresa URI</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Deschideţi cerere de plată prin intermediul adresei URI sau a fişierului</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>adresa URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Selectaţi fişierul de cerere de plată</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>Selectaţi fişierul de cerere de plată de deschis</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Setări</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Principal</translation>
    </message>
    <message>
        <source>Automatically start Bitcoin after logging in to the system.</source>
        <translation>Porneşte automat programul Bitcoin la pornirea computerului.</translation>
    </message>
    <message>
        <source>&amp;Start Bitcoin on system login</source>
        <translation>&amp;S Porneşte Bitcoin la pornirea sistemului</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Resetează toate setările clientului la valorile implicite.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;Resetează opțiunile</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Retea</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>expert</translation>
    </message>
    <message>
        <source>Automatically open the Bitcoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Deschide automat în router portul aferent clientului Bitcoin. Funcţionează doar în cazul în care routerul e compatibil UPnP şi opţiunea e activată.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Mapeaza portul folosind &amp;UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy &amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Portul pe care se concetează proxy serverul (de exemplu: 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Fereastra</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Afişează doar un icon in tray la ascunderea ferestrei</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;M Ascunde în tray în loc de taskbar</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Ascunde fereastra în locul părăsirii programului în momentul închiderii ferestrei. Când acestă opţiune e activă, aplicaţia se va opri doar în momentul selectării comenzii Quit din menu.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>&amp;i Ascunde fereastra în locul închiderii programului</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Afişare</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>Interfata &amp; limba userului</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting Bitcoin.</source>
        <translation>Limba interfeței utilizatorului poate fi setat aici. Această setare va avea efect după repornirea Bitcoin.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Unitatea de măsură pentru afişarea sumelor:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Alege subdiviziunea folosită la afişarea interfeţei şi la trimiterea de bitcoin.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Dacă să se afişeze controlul caracteristicilor monedei sau nu.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp; OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp; Renunta</translation>
    </message>
    <message>
        <source>default</source>
        <translation>Initial</translation>
    </message>
    <message>
        <source>none</source>
        <translation>nimic</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Confirmă resetarea opțiunilor</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Este necesar un restart al clientului pentru a activa schimbările.</translation>
    </message>
    <message>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation>Clientul va fi închis, doriţi să continuaţi?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Această schimbare va necesita un restart al clientului.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Adresa bitcoin pe care a-ti specificat-o este invalida</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin network after a connection is established, but this process has not completed yet.</source>
        <translation>Informațiile afișate pot neactualizate. Portofelul tău se sincronizează automat cu rețeaua Bitcoin după ce o conexiune este stabilită, dar acest proces nu a fost finalizat încă.</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Disponibil:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Balanța ta curentă de cheltuieli</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>În aşteptare:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Totalul tranzacțiilor care nu sunt confirmate încă și care nu sunt încă adunate la balanța de cheltuieli</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Nematurizat:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Balanta minata care nu s-a maturizat inca</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Balanța totală curentă</translation>
    </message>
    <message>
        <source>out of sync</source>
        <translation>Nu este sincronizat</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation>Gestionare URI</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>Adresă pentru plată nevalidă %1</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation>Cereti plata cu suma de %1 este prea mica (considerata praf)</translation>
    </message>
    <message>
        <source>Payment request error</source>
        <translation>Eroare la cererea de plată</translation>
    </message>
    <message>
        <source>Cannot start bitcoin: click-to-pay handler</source>
        <translation>Nu poate porni bitcoin: regula clic-pentru-plata</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>Cereri de plată neverificate prin script-uri personalizate de plată nu sunt suportate.</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>rambursare de la %1</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Eroare la comunicarea cu %1: %2</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Răspuns greșit de la server %1</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Plată acceptată</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>Eroare în cererea de rețea</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Sumă</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 h</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    </context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Salvarea imaginii ...</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>Copierea imaginii</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>Salvează codul QR</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>Imagine de tip PNG (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client name</source>
        <translation>Nume client</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Versiune client</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informație</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Fereastra de depanare</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Using OpenSSL version</source>
        <translation>Foloseste versiunea OpenSSL</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Durata pornirii</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Rețea</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Numele</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Numărul de conexiuni</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Lanț de blocuri</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Numărul curent de blocuri</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Data ultimului bloc</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Deschide</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Consolă</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>Traficul in rețea</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Ştergeţi</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Totaluri</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>în:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Ieșire.</translation>
    </message>
    <message>
        <source>Build date</source>
        <translation>Construit la data</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Loguri debug</translation>
    </message>
    <message>
        <source>Open the Bitcoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Deschide logurile debug din directorul curent. Aceasta poate dura cateva secunde pentru fisierele mai mari</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Curăță consola</translation>
    </message>
    <message>
        <source>Welcome to the Bitcoin RPC console.</source>
        <translation>Bun venit la consola bitcoin RPC</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Foloseste sagetile sus si jos pentru a naviga in istoric si &lt;b&gt;Ctrl-L&lt;/b&gt; pentru a curata.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Scrie &lt;b&gt;help&lt;/b&gt; pentru a vedea comenzile disponibile</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp; suma:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etichetă:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp; mesaj:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>Refolositi una din adresele de primire folosite in prealabil. Refolosirea adreselor poate crea probleme de securitate si confidentialitate. Nu folositi aceasta optiune decat daca o cerere de regenerare a platii a fost facuta in prealabil.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>&amp;Refolosirea unei adrese de primire (nu este recomandat)</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Folosește acest formular pentru a solicita plăți. Toate câmpurile sunt &lt;b&gt;opționale&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Stergeti toate campurile formularului</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Stergeti</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Istoricul platilor a fost cerut</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Cereti plata</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Arata cererea selectata (acelas lucru ca si dublu-click pe o inregistrare)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Arată</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Elimină</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copiază eticheta</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Copiaţi mesajul</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copiază suma</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>Cod QR</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Copiati &amp;URl</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Copiati &amp;Adresa</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Salvarea imaginii ...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Cereti plata pentru %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Informatiile platii</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>Identificator uniform de resurse</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresă</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Sumă</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etichetă</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mesaj</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>URI rezultat este prea lung, încearcă să reduci textul pentru etichetă / mesaj.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Eroare la codarea URl-ului în cod QR.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etichetă</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mesaj</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Sumă</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(fără etichetă)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(nici un mesaj)</translation>
    </message>
    <message>
        <source>(no amount)</source>
        <translation>(suma nulă)</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Trimite monede</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Intrări</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>Selectie automatică</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Fonduri insuficiente!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Cantitate:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Octeţi:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Sumă:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioritate:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Taxa:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>După taxe:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Schimbaţi:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Trimite simultan către mai mulți destinatari</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>&amp;Adaugă destinatar</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Stergeti toate campurile formularului</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Șterge &amp;tot</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balanță:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Confirmă operațiunea de trimitere</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;S Trimite</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Confirmă trimiterea de monede</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 la %2</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Copiaţi quantitea</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copiază suma</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Copiaţi taxele</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Copiaţi după taxe</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Copiaţi octeţi</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Copiaţi prioritatea</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Copiaţi schimb</translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation>Suma totală %1 (= %2)</translation>
    </message>
    <message>
        <source>or</source>
        <translation>sau</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>Adresa destinatarului nu este validă, vă rugăm să o verificaţi.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Suma de plată trebuie să fie mai mare decât 0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Suma depășește soldul contului.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Totalul depășește soldul contului dacă se include și plata comisionului de %1.</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>S-a descoperit o adresă care figurează de două ori. Expedierea se poate realiza către fiecare adresă doar o singură dată pe operațiune.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Creare de tranzactie nereusita!</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Tranzactia a fost respinsa! Acest lucru se poate intampla daca o parte din monedele tale din portofel au fost deja cheltuite, la fel ca si cum ai fi folosit o copie a wallet.dat si monedele au fost cheltuite in copie, dar nu au fost marcate si si cheltuite si aici.</translation>
    </message>
    <message>
        <source>Warning: Invalid Bitcoin address</source>
        <translation>Atentie: Adresa Bitcoin invalida!</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(fără etichetă)</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>Atentie: Schimbare de adresa necunoscuta</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Ești sigur că vrei să trimiți?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>adăugat ca taxă de tranzacție</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>Su&amp;mă:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Plătește că&amp;tre:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Introdu o etichetă pentru această adresă pentru a fi adăugată în lista ta de adrese</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etichetă:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Alegeti adrese folosite in prealabil.</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Aceasta este o tranzacţie normală.</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Lipește adresa din clipboard</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Scoate aceasta introducere</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Mesaj:</translation>
    </message>
    <message>
        <source>This is a verified payment request.</source>
        <translation>Aceasta este o cerere de plata verificata</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Introduceti eticheta pentru ca aceasta adresa sa fie introdusa in lista de adrese folosite</translation>
    </message>
    <message>
        <source>This is an unverified payment request.</source>
        <translation>Aceasta este o cerere de plata neverificata</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Plateste catre:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Memo:</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Bitcoin Core is shutting down...</source>
        <translation>Bitcoin Core se închide...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Nu închide calculatorul până ce această fereastră nu dispare.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Semnatura- Semneaza/verifica un mesaj</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Semneaza Mesajul</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Puteti semna mesaje cu adresa dumneavoastra pentru a demostra ca sunteti proprietarul lor. Aveti grija sa nu semnati nimic vag, deoarece atacurile de tip phishing va pot pacali sa le transferati identitatea. Semnati numai declaratiile detaliate cu care sunteti deacord.</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Alegeti adrese folosite in prealabil</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Lipiţi adresa copiată in clipboard.</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Introduce mesajul pe care vrei sa il semnezi, aici.</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Semnătură</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Copiaza semnatura curenta in clipboard-ul sistemului</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Bitcoin address</source>
        <translation>Semneaza mesajul pentru a dovedi ca detii acesta adresa Bitcoin</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Semnează &amp;Message</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Reseteaza toate spatiile mesajelor semnate.</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Şterge &amp;tot</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>Verifica mesajul</translation>
    </message>
    <message>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Introduceti adresa de semnatura, mesajul (asigurati-va ca ati copiat spatiile, taburile etc. exact) si semnatura dedesubt pentru a verifica mesajul. Aveti grija sa nu cititi mai mult in semnatura decat mesajul in sine, pentru a evita sa fiti pacaliti de un atac de tip man-in-the-middle.</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Bitcoin address</source>
        <translation>Verifica mesajul pentru a fi sigur ca a fost semnat cu adresa Bitcoin specifica</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Verifică &amp;Message</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Reseteaza toate spatiile mesajelor semnate.</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation>Click "Semneaza msajul" pentru a genera semnatura</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Adresa introdusa nu este valida</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Te rugam verifica adresa si introduce-o din nou</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Adresa introdusa nu se refera la o cheie.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Blocarea portofelului a fost intrerupta</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Cheia privata pentru adresa introdusa nu este valida.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Semnarea mesajului a esuat</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Mesaj Semnat!</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Aceasta semnatura nu a putut fi decodata</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Verifica semnatura si incearca din nou</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>Semnatura nu seamana!</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Verificarea mesajului a esuat</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Mesaj verificat</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Bitcoin Core</source>
        <translation>Bitcoin Core</translation>
    </message>
    <message>
        <source>The Bitcoin Core developers</source>
        <translation>Dezvoltatorii Bitcoin Core</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Deschis până la %1</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1/deconectat</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/neconfirmat</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 confirmări</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Stare</translation>
    </message>
    <message numerus="yes">
        <source>, broadcast through %n node(s)</source>
        <translation><numerusform>, distribuit prin %n nod</numerusform><numerusform>, distribuit prin %n noduri</numerusform><numerusform>, distribuit prin %n de noduri</numerusform></translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Sursa</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Generat</translation>
    </message>
    <message>
        <source>From</source>
        <translation>De la</translation>
    </message>
    <message>
        <source>To</source>
        <translation>Către</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>Adresa posedata</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etichetă</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Credit</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation><numerusform>se maturizează în încă %n bloc</numerusform><numerusform>se maturizează în încă %n blocuri</numerusform><numerusform>se maturizează în încă %n de blocuri</numerusform></translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>nu este acceptat</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Debit</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Comisionul tranzacţiei</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Suma netă</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mesaj</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentarii</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>ID-ul tranzactiei</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>Comerciant</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to "not accepted" and it won't be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Monezile generate trebuie sa creasca %1 block-uri inainte sa poata fi cheltuite. Cand ati generat acest block, a fost transmis retelei pentru a fi adaugat la lantul de block-uri. Aceasta  se poate intampla ocazional daca alt nod genereaza un block la numai cateva secunde de al tau.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Informatii pentru debug</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Tranzacţie</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>Intrari</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Sumă</translation>
    </message>
    <message>
        <source>true</source>
        <translation>Adevarat!</translation>
    </message>
    <message>
        <source>false</source>
        <translation>Fals!</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, nu s-a propagat încă</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>necunoscut</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Detaliile tranzacției</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Acest panou afișează o descriere detaliată a tranzacției</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipul</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Deschis până la %1</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Confirmat (%1 confirmări)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Acest bloc nu a fost recepționat de niciun alt nod și probabil nu va fi acceptat!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Generat dar neacceptat</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>Deconectat</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>Neconfirmat</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>Confirmare (%1 dintre %2 confirmări recomandate)</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Recepționat cu</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Primit de la</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Trimis către</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Plată către tine</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Produs</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Starea tranzacției. Treci cu mausul peste acest câmp pentru afișarea numărului de confirmări.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Data și ora la care a fost recepționată tranzacția.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Tipul tranzacției.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Adresa de destinație a tranzacției.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Suma extrasă sau adăugată la sold.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Toate</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Astăzi</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Săptămâna aceasta</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Luna aceasta</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Luna trecută</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Anul acesta</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Între...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Recepționat cu</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Trimis către</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Către tine</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Produs</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Altele</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Introdu adresa sau eticheta pentru căutare</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Cantitatea minimă</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Copiază adresa</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copiază eticheta</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copiază suma</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Copiază ID tranzacție</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Editează eticheta</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Arată detaliile tranzacției</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>Exportare Istoric Tranzacţii</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Exportare Eşuată</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>S-a produs o eroare încercând să se salveze istoricul tranzacţiilor la %1.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Exportare Reuşită</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Istoricul tranzacţiilor a fost salvat cu succes la %1.</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Fișier text cu valori separate prin virgulă (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmat</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipul</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etichetă</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresă</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Interval:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>către</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>Nu a fost încărcat niciun portofel.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Trimite Bitcoin</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportă</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporta datele din tab-ul curent într-un fișier</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Fă o copie de siguranță a portofelului</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Date portofel (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Copia de rezerva a esuat</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>S-a produs o eroare încercând să se salveze datele portofelului la %1.</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Datele portofelului s-au salvat cu succes la %1.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Copia de siguranță efectuată cu succes</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Setări:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Specifică dosarul de date</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Conectează-te la nod pentru a obține adresele partenerilor, și apoi deconectează-te</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Specifică adresa ta publică</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Se acceptă comenzi din linia de comandă și comenzi JSON-RPC</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Rulează în fundal ca un demon și acceptă comenzi</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Utilizează rețeaua de test</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Acceptă conexiuni din afară (implicit: 1  dacă nu se folosește -proxy sau -connect)</translation>
    </message>
    <message>
        <source>%s, you must set a rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=bitcoinrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s "Bitcoin Alert" admin@foo.com
</source>
        <translation>%s trebuie sa setezi o parola rpc in fisierul de configurare
%s
Este recomandat sa folosesti aceasta parola aleatorie:
rpcuser=bitcoinrpc
parola rpc=%s
(nu este necesar ca sa iti amintesti aceasta parola)
Numele de utilizator si parola NU trebuie sa fie la fel.
Daca fisierul nu exista, creaza-l cu fisier de citit permis doar proprietarului.
Este de asemenea recomandat sa setezi alerta de notificare ca sa primesti notificari ale problemelor;
spre exemplu: alertnotify=echo %%s | mail -s "Alerta Bitcoin" admin@foo.com

</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Atasati adresei date si ascultati totdeauna pe ea. Folositi [host]:port notatia pentru IPv6</translation>
    </message>
    <message>
        <source>Error: The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Eroare: Tranzactia a fost respinsa! Acest lucru se poate intampla daca anumite monezi din portofelul dumneavoastra au fost deja cheltuite, deasemenea daca ati folosit o copie a fisierului wallet.dat si monezile au fost folosite in acea copie dar nu au fost marcate ca fiind folosite acolo.</translation>
    </message>
    <message>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds!</source>
        <translation>Eroare: Aceasta tranzactie necesita o taxa de cel putin %s din cauza sumei, complexitatii sau folosirii fondurilor recent primite!</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Executati comanda cand o tranzactie a portofelului se schimba (%s in cmd este inlocuit de TxID)</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>Aceasta este o versiune de test preliminara - va asumati riscul folosind-o - nu folositi pentru minerit sau aplicatiile comerciantilor.</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Atentie: setarea -paytxfee este foarte ridicata! Aceasta este taxa tranzactiei pe care o vei plati daca trimiti o tranzactie.</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>Atentie: Reteaua nu pare sa fie deacord in totalitate! Aparent niste mineri au probleme. </translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Atentie: Aparent, nu suntem deacord cu toti membrii nostri! Va trebui sa faci un upgrade, sau alte noduri ar necesita upgrade. </translation>
    </message>
    <message>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Atentie: eroare la citirea fisierului wallet.dat! Toate cheile sunt citite corect, dar datele tranzactiei sau anumite intrari din agenda sunt incorecte sau lipsesc.</translation>
    </message>
    <message>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Atentie: fisierul wallet.dat este corupt, date salvate! Fisierul original wallet.dat a fost salvat ca wallet.{timestamp}.bak in %s; daca balansul sau tranzactiile sunt incorecte ar trebui sa restaurati dintr-o copie de siguranta. </translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; poate fi:</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>Încearcă recuperarea cheilor private dintr-un wallet.dat corupt</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Optiuni creare block</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s)</source>
        <translation>Conecteaza-te doar la nod(urile) specifice</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Baza de date 'bloc' defectată a fost detectată</translation>
    </message>
    <message>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Descopera propria ta adresa IP (intial: 1)</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Doriți să reconstruiți baza de date 'bloc' acum?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Eroare la inițializarea bazei de date de blocuri</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Eroare la initializarea mediului de baza de date a portofelului %s!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Eroare la încărcarea bazei de date de blocuri</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Eroare la deschiderea bazei de date de blocuri</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Eroare: Spațiu pe disc redus!</translation>
    </message>
    <message>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation>Eroare: Portofel blocat, nu se poate crea o tranzacție!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Am esuat ascultarea pe orice port. Folositi -listen=0 daca vreti asta.</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Incorect sau nici un bloc de Geneza găsite. Directorul de retea greşit?</translation>
    </message>
    <message>
        <source>Invalid -onion address: '%s'</source>
        <translation>Adresa -onion invalidă: '%s'</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Nu sunt destule descriptoare disponibile.</translation>
    </message>
    <message>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>Reconstruirea indexului lantului de block-uri din fisierele actuale blk000???.dat</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>Setaţi dimensiunea maximă a unui block în bytes (implicit: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Specifică fișierul wallet (în dosarul de date)</translation>
    </message>
    <message>
        <source>This is intended for regression testing tools and app development.</source>
        <translation>Este folosita pentru programe de testare a regresiei in algoritmi si  dezvoltare de alte aplicatii. </translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Se verifică blocurile...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Se verifică portofelul...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Portofelul %s se află în afara dosarului de date %s</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Optiuni de portofel</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation>Trebuie să reconstruiești baza de date folosind -reindex pentru a schimba -txindex</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>Importă blocuri dintr-un fișier extern blk000??.dat</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>Executati comanda cand o alerta relevanta este primita sau vedem o bifurcatie foarte lunga (%s in cmd este inlocuti de mesaj)</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informație</translation>
    </message>
    <message>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: '%s'</source>
        <translation>Suma invalida pentru -minrelaytxfee=&lt;suma&gt;:'%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: '%s'</source>
        <translation>Suma invalida pentru -mintxfee=&lt;suma&gt;: '%s'</translation>
    </message>
    <message>
        <source>Print block on startup, if found in block index</source>
        <translation>Publica bloc la pornire daca exista in index-ul de blocuri. </translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Trimite informațiile trace/debug la consolă în locul fișierului debug.log</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Micsorati fisierul debug.log la inceperea clientului (implicit: 1 cand nu -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Semnarea tranzacției a eșuat</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Suma tranzacționată este prea mică</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>Sumele tranzacționate trebuie să fie pozitive</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Tranzacția este prea mare</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>Foloseste UPnP pentru a vedea porturile (initial: 1 cand listezi)</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Utilizator pentru conexiunile JSON-RPC</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Avertizare</translation>
    </message>
    <message>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>Atenție: această versiune este depășită, este necesară actualizarea!</translation>
    </message>
    <message>
        <source>on startup</source>
        <translation>in timpul pornirii</translation>
    </message>
    <message>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat corupt, recuperare eșuată</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Parola pentru conexiunile JSON-RPC</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Execută comanda când cel mai bun bloc se modifică (%s în cmd este înlocuit cu hash-ul blocului)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format</source>
        <translation>Actualizează portofelul la ultimul format</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Rescanează lanțul de bloc pentru tranzacțiile portofel lipsă</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Folosește OpenSSL (https) pentru conexiunile JSON-RPC</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>Acest mesaj de ajutor</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Permite căutări DNS pentru -addnode, -seednode și -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Încarc adrese...</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Eroare la încărcarea wallet.dat: Portofel corupt</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Eroare la încărcarea wallet.dat</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>Adresa -proxy nevalidă: '%s'</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>Rețeaua specificată în -onlynet este necunoscută: '%s'</translation>
    </message>
    <message>
        <source>Cannot resolve -bind address: '%s'</source>
        <translation>Nu se poate rezolva adresa -bind: '%s'</translation>
    </message>
    <message>
        <source>Cannot resolve -externalip address: '%s'</source>
        <translation>Nu se poate rezolva adresa -externalip: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s'</source>
        <translation>Suma nevalidă pentru -paytxfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount</source>
        <translation>Sumă nevalidă</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Fonduri insuficiente</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Încarc indice bloc...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Adaugă un nod la care te poți conecta pentru a menține conexiunea deschisă</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Încarc portofel...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Nu se poate retrograda portofelul</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Nu se poate scrie adresa implicită</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Rescanez...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Încărcare terminată</translation>
    </message>
    <message>
        <source>To use the %s option</source>
        <translation>Pentru a folosi opțiunea %s</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Eroare</translation>
    </message>
</context>
</TS>